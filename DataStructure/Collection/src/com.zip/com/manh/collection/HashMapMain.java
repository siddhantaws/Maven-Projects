package com.manh.collection;

public class HashMapMain 
{
	public static void main(String[] args) 
	{
		Map<String, String> map=new HashMap<>();
		map.put("FB", "A");
		map.put("B", "A");
		//map.put("Ea", "A");
	}
}
